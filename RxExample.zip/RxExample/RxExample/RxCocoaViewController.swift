//
//  RxCocoaViewController.swift
//  RxExample
//
//  Created by Mize on 2019/1/8.
//  Copyright © 2019 Mize. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class RxCocoaViewController: UIViewController {

    @IBOutlet weak var textField: UITextField!
    
    @IBOutlet weak var label: UILabel!
    
    var disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func bindAction(_ sender: Any) {

        // 將 TextField的Text綁定到Label上
        textField.rx.text.asObservable().bind(to: label.rx.text).disposed(by: disposeBag)
        
    }
    
    @IBAction func unbindAction(_ sender: Any) {
        
        //解除綁定
        disposeBag = DisposeBag()
        
    }
    
}
