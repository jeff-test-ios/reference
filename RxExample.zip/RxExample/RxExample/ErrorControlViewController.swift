//
//  ErrorControlViewController.swift
//  RxExample
//
//  Created by Mize on 2019/1/8.
//  Copyright © 2019 Mize. All rights reserved.
//

import UIKit
import RxSwift

enum ExampleErrors : Error {
    case tooLarge
    case anotherError
}

class ErrorControlViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func catchError(_ sender: Any) {
        
        /*
         Error基礎：
         如果在一個Observable中，拋出Error時會進入onError事件
         */
        
        // 範例：在數據大於2時會輸出錯誤
        _ = Observable.from([1,2,3,4]).flatMap { (data) -> Observable<Int> in
            if data > 2 {
                throw ExampleErrors.tooLarge
            }
            return Observable.just(data)
        }.subscribe(onNext: { (data) in
            print("onNext = \(data)")
        }, onError: { (error) in
            print("onError = \(error)")
        }, onCompleted: {
            print("onCompleted")
        }, onDisposed: {
            print("onDisposed")
        })
        
        /*
         輸出結果
            onNext = 1
            onNext = 2
            onError = tooLarge
            onDisposed
         */
        
        //------------------------------------------------------------------------------------------------------------------

        /*
         catchError為當Stream發生Error時，將之捕捉處理並拋出新的Observable，可在錯誤時做另外的處理
         */
        
        _ = Observable.from([1,2,3,4]).flatMap { (data) -> Observable<Int> in
            if data > 2 {
                throw ExampleErrors.tooLarge
            }
            return Observable.just(data)
        }.catchError({ (error) -> Observable<Int> in
            return Observable.empty() // 發生錯誤時終止後面執行，注意：這種處理方式的話後面就會接收不到Error
            //throw ExampleErrors.anotherError // 也可以將Error處理後拋出另外的Error
        }).subscribe(onNext: { (data) in
            print("onNext = \(data)")
        }, onError: { (error) in
            print("onError = \(error)")
        }, onCompleted: {
            print("onCompleted")
        }, onDisposed: {
            print("onDisposed")
        })
        
        /*
         輸出結果
            onNext = 1
            onNext = 2
            onCompleted
            onError = anotherError // 如果在catchError時拋出另外的錯誤
            onDisposed
         */
    }
    
    @IBAction func retry(_ sender: Any) {
        
        /*
         retry為當Stream發生Error時，會嘗試重新執行整個Stream，常用在API的訪問上
         */
        
        _ = Observable.from([1,2,3,4]).flatMap { (data) -> Observable<Int> in
            if data > 2 {
                throw ExampleErrors.tooLarge
            }
            return Observable.just(data)
        }
        .retry(2)
        .subscribe(onNext: { (data) in
            print("onNext = \(data)")
        }, onError: { (error) in
            print("onError = \(error)")
        }, onCompleted: {
            print("onCompleted")
        }, onDisposed: {
            print("onDisposed")
        })
        
        /*
         輸出結果
            onNext = 1
            onNext = 2
            onNext = 1
            onNext = 2
            onError = tooLarge
            onDisposed
         */
        
    }

}
