//
//  StreamsControlViewController.swift
//  RxExample
//
//  Created by Mize on 2019/1/8.
//  Copyright © 2019 Mize. All rights reserved.
//

import UIKit
import RxSwift

class StreamsControlViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func zip(_ sender: Any) {
        
        /*
         Observable.zip可以將兩個含以上的的Observable合併為一個Observable
         zip的特點是會"併發處理"並且會等所有來源的Observable都OnNext時才會"同時"將數據輸出
         如來源數量不一致時只會輸出同數量的部分
         
         注意：如果有任一來源Observable發生Error時，就不會再繼續往下輸出數據與執行
         */
        
        let observable = Observable<Int>.from([1,2,3,4])
        let observable2 = Observable<Int>.from([5,6,7,8])
        
        _ = Observable.zip(observable, observable2) { (data1, data2) -> String in
            return "\(data1) \(data2)"
        }.subscribe(onNext: { (string) in
            print("onNext = \(string)")
        }, onCompleted: {
            print("onCompleted")
        }, onDisposed: {
            print("onDisposed")
        })
        
        /*
         輸出結果
            onNext = 1 5
            onNext = 2 6
            onNext = 3 7
            onNext = 4 8    // 如果observable2數據只有5,6,7時此行不輸出
            onCompleted
            onDisposed
         */
    }
    
    @IBAction func concat(_ sender: Any) {
        
        /*
         Observable.concat可以將兩個含以上的的Observable"串接"成一個Observable，會"依序"執行所有來源的Observable
         在來源Observable沒有onCompleted時不會執行下一個Observable
         
         注意：如果有任一來源Observable發生Error時，就不會再繼續往下輸出數據與執行
         */
        let observable = Observable<Int>.from([1,2,3,4])
        let observable2 = Observable<Int>.from([5,6,7,8])
        _ = Observable.concat([observable, observable2]).subscribe(onNext: { (data) in
            print("onNext = \(data)")
        }, onError: { (error) in
            print("onError = \(error)")
        }, onCompleted: {
            print("onCompleted")
        }, onDisposed: {
            print("onDisposed")
        })
        
        /*
         輸出結果
            onNext = 1
            onNext = 2
            onNext = 3
            onNext = 4
            onNext = 5
            onNext = 6
            onNext = 7
            onNext = 8
            onCompleted
            onDisposed
         */
        
    }

}
