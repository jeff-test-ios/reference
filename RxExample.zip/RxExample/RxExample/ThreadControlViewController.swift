//
//  ThreadControlViewController.swift
//  RxExample
//
//  Created by Mize on 2019/1/8.
//  Copyright © 2019 Mize. All rights reserved.
//

import UIKit
import RxSwift

class ThreadControlViewController: UIViewController {

    public let backgroundScheduler = SerialDispatchQueueScheduler(qos: DispatchQoS.background)

    override func viewDidLoad() {
        super.viewDidLoad()
        

    }
    
    /*
     Rx的一大特色為執行續操作切換非常容易，主要為observeOn與subscribeOn兩個操作符，兩個的作用區域與使用狀況不一樣
     實際使用狀況下執行續操作較複雜，尤其是observeOn與subscribeOn混合使用時，在這邊只做簡單的案例說明
     */
    
    @IBAction func observeOn(_ sender: Any) {
        
        // 一般Observable
        _ = Observable.just(1).map { (data) -> Int in
            print("is Main Thread? = \(Thread.current.isMainThread)")
            return data
        }.subscribe(onNext: { (data) in
            print("is Main Thread? = \(Thread.current.isMainThread)")
        })
        
        /*
         輸出結果
            is Main Thread? = true
            is Main Thread? = true
         */
        
        //------------------------------------------------------------------------------------------------------------------

        // 加上observeOn
        _ = Observable.just(1).map { (data) -> Int in
            print("is Main Thread? = \(Thread.current.isMainThread)")
            return data
        }
        .observeOn(backgroundScheduler)
        .subscribe(onNext: { (data) in
            print("is Main Thread? = \(Thread.current.isMainThread)")
        })
        
        /*
         輸出結果
            is Main Thread? = true
            is Main Thread? = false
         */
        
        //------------------------------------------------------------------------------------------------------------------

        //observeOn的放置區域會影響結果
        _ = Observable.just(1)
            .observeOn(backgroundScheduler)
            .map { (data) -> Int in
                print("is Main Thread? = \(Thread.current.isMainThread)")
                return data
            }
            .subscribe(onNext: { (data) in
                print("is Main Thread? = \(Thread.current.isMainThread)")
            })
        
        /*
         輸出結果
         is Main Thread? = false
         is Main Thread? = false
         */
    }
    
    @IBAction func subscribeOn(_ sender: Any) {
        
        // 加上subscribeOn
        _ = Observable.just(1)
            .map { (data) -> Int in
                print("is Main Thread? = \(Thread.current.isMainThread)")
                return data
            }
            .subscribeOn(backgroundScheduler)
            .subscribe(onNext: { (data) in
                print("is Main Thread? = \(Thread.current.isMainThread)")
            })
        /*
         輸出結果
            is Main Thread? = false
            is Main Thread? = false
         */
        
        //------------------------------------------------------------------------------------------------------------------

        // subscribeOn的位置不影響結果
        _ = Observable.just(1)
            .subscribeOn(backgroundScheduler)
            .map { (data) -> Int in
                print("is Main Thread? = \(Thread.current.isMainThread)")
                return data
            }
            .subscribe(onNext: { (data) in
                print("is Main Thread? = \(Thread.current.isMainThread)")
            })
        /*
         輸出結果
         is Main Thread? = false
         is Main Thread? = false
         */
        
    }
    
}
