//
//  BaseViewController.swift
//  RxExample
//
//  Created by Mize on 2019/1/8.
//  Copyright © 2019 Mize. All rights reserved.
//

import UIKit
import RxSwift

class BaseViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func just(_ sender: Any) {
        
        /*
         Observable<Element>為Rx中最基礎也是最泛用的型別
         Element為泛型，可自由指定任意型別做為這個流(Stream)的"數據"
         */
        
        // Observable.just為最簡單的建立方式
        // 另外還有 Observable.from / Observable.create等語法
        
        // 建立一個Observable<Int>
        _ = Observable.just(1)
        
        // 建立一個Observable<String>
        _ = Observable.just("Hello world")
        
    }
    
    @IBAction func subscribe(_ sender: Any) {
        
        /*
         在建立起Observable之後，這個Observable在尚未被"訂閱"時，不會有任何的反應，包含所有的衍生型別皆是如此
         而一個Observable在起始 ～ 結束就是一個流(Stream)
         以下為範例
         */
        
        // 建立一個Observable<Int>
        let observable = Observable.just(1)
        
        // 訂閱
        _ = observable.subscribe(onNext: { (data) in
            print("we have a data = \(data)")
        })
        
        /*
        輸出結果
            we have a data = 1
        */
        
    }
    
    @IBAction func lifeCycle(_ sender: Any) {
        
        /*
         一個Observable有著完整的生命週期，或稱之為事件
         
         在subscribe可以使用的為
         onNext
         onError
         onCompleted
         onDisposed
         
         在do時可使用的為
         onNext
         onError
         onCompleted
         onSubscribe
         onSubscribed
         onDispose
         */

        // 使用Array<Int>來建立一個Observable<Int>，注意這邊是使用from而不是just
        let observable = Observable.from([1,2,3,4])
        
        _ = observable.subscribe(onNext: { (data) in
            print("onNext = \(data)")
        }, onError: { (error) in
            print("onError = \(error)")
        }, onCompleted: {
            print("onCompleted")
        }, onDisposed: {
            print("onDisposed")
        })
        
        /*
         輸出結果
            onNext = 1
            onNext = 2
            onNext = 3
            onNext = 4
            onCompleted
            onDisposed
         */
        
        //------------------------------------------------------------------------------------------------------------------
        
        /*
         所有的Observable都是以subscribe為終點，終點之後無法再進行任何的Stream操作
         而如果是希望在Stream的"過程"中取得相關的事件，則必須使用do來處理
         而且do只是一個操作語法，所以如果只有do的話這個Stream還是不會動作，所以還是必須subscribe
         do如果與subscribe混用時較為複雜，需注意順序避免出現Bug
         */
        _ = observable.do(onNext: { (data) in
            print("do onNext = \(data)")
        }, onError: { (error) in
            print("do onError = \(error)")
        }, onCompleted: {
            print("do onCompleted")
        }, onSubscribe: {
            print("do onSubscribe")
        }, onSubscribed: {
            print("do onSubscribed")
        }, onDispose: {
            print("do onDisposed")
        }).subscribe(onNext: { (data) in
            print("subscribe onNext = \(data)")
        }, onError: { (error) in
            print("subscribe onError = \(error)")
        }, onCompleted: {
            print("subscribe onCompleted")
        }, onDisposed: {
            print("subscribe onDisposed")
        })
        
        /*
         輸出結果
            do onSubscribe
            do onSubscribed
            do onNext = 1
            subscribe onNext = 1
            do onNext = 2
            subscribe onNext = 2
            do onNext = 3
            subscribe onNext = 3
            do onNext = 4
            subscribe onNext = 4
            do onCompleted
            subscribe onCompleted
            subscribe onDisposed
            do onDisposed
         */
        
        //------------------------------------------------------------------------------------------------------------------
        
        // 使用just的範例，注意Element的型別為Array<Int>
        let example = Observable.just([1,2,3,4])
        
        _ = example.subscribe(onNext: { (data) in
            print("onNext = \(data)")
        }, onError: { (error) in
            print("onError = \(error)")
        }, onCompleted: {
            print("onCompleted")
        }, onDisposed: {
            print("onDisposed")
        })
        
        /*
         輸出結果
            onNext = [1, 2, 3, 4]
            onCompleted
            onDisposed
         */
        
        /*
         如果不打算使用任何subscribe時的事件時，可以不需要指定事件
         */
        _ = example.subscribe()
        
    }
    
    @IBAction func disposing(_ sender: Any) {
        
        /*
         在每次subscribe之後都會回傳一個Disposable，可以用來手動終止該Stream
         */
        
        // 建立一個會連續發射數據的Observable
        let observable = Observable<Int>.interval(1, scheduler: MainScheduler.instance)
        
        // 訂閱並列印數據
        let disposable = observable.subscribe(onNext: { (data) in
            print("onNext = \(data)")
        }, onError: { (error) in
            print("onError = \(error)")
        }, onCompleted: {
            print("onCompleted")
        }, onDisposed: {
            print("onDisposed")
        })
        
        // 三秒後手動終止
        DispatchQueue.global().async {
            sleep(3)
            disposable.dispose()
        }
        
        /*
         輸出結果
            onNext = 0
            onNext = 1
            onNext = 2
            onDisposed
         */
        
        //------------------------------------------------------------------------------------------------------------------
        
        /*
         Rx提供了一個Bag來做Disposable的集中管理輔助，可將希望一起管理的Disposable集中在一起，並可依序Dispose
         通常用於同一個頁面中所有Stream集中管理，並可在ViewController被GC回收時自動一起回收並Dispose掉Stream
         
         通常在subscribe之後直接串接上disposed可將Disposable直接insert到bag裡面
         */
        
        let bag = DisposeBag()
        observable.subscribe().disposed(by: bag)
    }
    
    /*
     上面基礎的介紹了Observable的"基礎"知識
     接下來介紹一些簡易且常用的Element操作語法
     */
    
    @IBAction func map(_ sender: Any) {
        
        /*
         map為依序傳入Element並回傳任意型別R
         */
        
        // 建立Observable<Int>
        let observable = Observable.from([1,2,3,4])
        
        // 使用map將所有的Int轉換為String
        _ = observable.map { (integerData) -> String in
            return "Number \(integerData)"
        }.subscribe(onNext: { (stringData) in
            print("onNext = \(stringData)")
        })
        
        /*
         輸出結果
            onNext = Number 1
            onNext = Number 2
            onNext = Number 3
            onNext = Number 4
         */
        
    }
    
    @IBAction func filter(_ sender: Any) {
        
        /*
         filter為依序傳入Element並回傳Bool決定是否使用該Element
         */
        
        // 建立Observable<Int>
        let observable = Observable.from([1,2,3,4])
        
        // 篩選數字大於2
        _ = observable.filter { (data) -> Bool in
            return data > 2
        }.subscribe(onNext: { (data) in
            print("onNext = \(data)")
        })
        
        /*
         輸出結果
            onNext = 3
            onNext = 4
         */
        
    }
    
    @IBAction func flatmap(_ sender: Any) {
        
        /*
         flatMap為map的突變奇形種，一樣是依序傳入Element但卻回傳ObservableConvertibleType (基本上就是所有Observable與相關的衍生型別)
         可用來達成各種奇杷需求，通常用於"流程"上的串接，較常使用在API之間或API與畫面的處理
         */
        
        /*
         以下使用假API做示範，流成為：
         登入成功後取得個人暱稱
         */
        let observable = login(fakeResult: false).flatMap { (result) -> Observable<String> in
            
            if result { // 登入成功
                return self.getNickName() // 取得個人暱稱
            } else { // 登入失敗
                return Observable.empty() // 個人系慣的操作技巧之一，使用Empty終止後面所有的Stream操作
                //return Observable.error(CustomErrorType) // 或也可以拋出Error
            }
            
        }
        
        _ = observable.subscribe(onNext: { (nickName) in
            print("my nick name = \(nickName)")
        }, onError: { (error) in
            print("error throw \(error)")
        })
        
        /*
         case 1 輸出結果
            my nick name = GGININDER
         
         case 2 登入失敗使用Observable.empty 的輸出結果
            (不輸出任何結果)
         
         case 3 登入失敗使用Observable.error 的輸出結果
            error throw CustomErrorType
         */

        
    }
    
    // 假API - 登入
    func login(fakeResult: Bool) -> Observable<Bool> {
        return Observable.just(fakeResult)
    }
    
    // 假API - 取得個人暱稱
    func getNickName() -> Observable<String> {
        return Observable.just("GGININDER")
    }
    
    @IBAction func delay(_ sender: Any) {
        
        /*
         delay為延遲Stream在"此之後"的數據發送
         */
        
        _ = Observable.from([1,2,3,4]).map { (data) -> Int in
            NSLog("map data = \(data)");
            return data
        }
        .delay(3, scheduler: MainScheduler.instance)
        .subscribe(onNext: { (data) in
            NSLog("onNext = \(data)")
        })
        
        /*
         輸出結果
            15:16:20.142648 map data = 1
            15:16:20.142942 map data = 2
            15:16:20.143050 map data = 3
            15:16:20.143171 map data = 4
            15:16:23.144195 onNext = 1
            15:16:23.144757 onNext = 2
            15:16:23.145296 onNext = 3
            15:16:23.145734 onNext = 4
         */
        
    }
    
}
