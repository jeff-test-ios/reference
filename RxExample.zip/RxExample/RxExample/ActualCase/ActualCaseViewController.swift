//
//  ActualCaseViewController.swift
//  RxExample
//
//  Created by Mize on 2019/1/9.
//  Copyright © 2019 Mize. All rights reserved.
//

import UIKit

class ActualCaseViewController: UIViewController {

    @IBOutlet weak var accountTextField: UITextField!
    
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBOutlet weak var errorMessageLab: UILabel!
    
    var viewModel = ActualCaseViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        viewModel.viewState.subscribe(onNext: { (state) in
            
            // 根據ViewModel的ViewState做出相對應的畫面狀態
            switch state {
            case .Default:
                // 重置畫面初始狀態
                self.accountTextField.text = nil
                self.passwordTextField.text = nil
                self.errorMessageLab.text = nil
                
            case .LoginSuccess(let user):
                self.errorMessageLab.text = nil
                
                let alert = UIAlertController(title: "登入成功", message:
                    """
                    Hello
                    UserName = \(user.username ?? "Unknown")
                    Name = \(user.name ?? "Unknown")
                    """, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "ok", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                
            case .LoginFail(let error):
                
                self.accountTextField.text = nil //清空帳號密碼
                self.passwordTextField.text = nil
                self.errorMessageLab.text = "\(error)"
                
            }
        }).disposed(by: viewModel.bag)
    }

    @IBAction func loginAction(_ sender: Any) {
        viewModel.login(account: accountTextField.text ?? "", password: passwordTextField.text ?? "")
    }

}
