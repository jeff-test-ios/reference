//
//  JSONPlaceholderService.swift
//  RxExample
//
//  Created by Mize on 2019/1/9.
//  Copyright © 2019 Mize. All rights reserved.
//

import Foundation
import Moya

enum JSONPlaceholderService {
    case Login(account:String,password:String)
}

extension JSONPlaceholderService : TargetType {
    
    var baseURL: URL {
        return URL(string: "https://jsonplaceholder.typicode.com/")!;
    }
    
    var path: String {
        switch self {
        case .Login:
            return "users";
        }
    }
    
    var method: Moya.Method {
        switch self {
        case .Login:
            return .get;
        }
    }
    
    var sampleData: Data {
        return Data();
    }
    
    var task: Task {
        var builder = MoyaTaskBuilder();
        
        switch self {
        case .Login(let account, let password):
            builder <= QueryParameter("username", account);
        }
        
        return builder.build();
    }
    
    var headers: [String : String]? {
        return nil;
    }
    
}
