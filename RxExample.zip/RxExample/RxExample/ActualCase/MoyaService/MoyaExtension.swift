//
//  MoyaExtension.swift
//  RxExample
//
//  Created by Mize on 2019/1/9.
//  Copyright © 2019 Mize. All rights reserved.
//

import Foundation
import Moya

/// MARK: 擴充簡易化的Moya使用的參數處理
struct QueryParameter {
    
    var name: String
    
    var value: Any?
    
    init(_ name: String,_ value: Any?)
    {
        self.name = name;
        self.value = value;
    }
}

infix operator <=

func <= (left: inout MoyaTaskBuilder, right: QueryParameter) {
    left.appendParameter(right);
}

func <= (left: inout MoyaTaskBuilder, right: MultipartFormData) {
    left.appendMultipart(right);
}

//使用工廠類的處理方式來優化Moya的Task建構
class MoyaTaskBuilder {
    
    private var params:[String: Any] = [:];
    
    private var multiparts:[MultipartFormData] = [];
    
    func appendParameter(_ parameter: QueryParameter) {
        guard parameter.value != nil else { return }
        params.updateValue(parameter.value!, forKey: parameter.name);
    }
    
    func appendMultipart(_ multipart:MultipartFormData) {
        multiparts.append(multipart);
    }
    
    func build() -> Task {
        if self.params.isEmpty && self.multiparts.isEmpty {
            return .requestPlain;
        } else if !self.params.isEmpty && !self.multiparts.isEmpty {
            return .uploadCompositeMultipart(multiparts, urlParameters: params);
        } else {
            if self.params.isEmpty {
                return .uploadMultipart(multiparts);
            } else {
                return .requestParameters(parameters: params, encoding: URLEncoding.default)
            }
        }
    }
    
}
