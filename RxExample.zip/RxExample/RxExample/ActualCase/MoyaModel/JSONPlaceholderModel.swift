//
//  JSONPlaceholderModel.swift
//  RxExample
//
//  Created by Mize on 2019/1/9.
//  Copyright © 2019 Mize. All rights reserved.
//

import Foundation
import Moya
import RxSwift
import ObjectMapper
import Moya_ObjectMapper

enum JSONPlaceholderError : Error {
   
    case LoginFail
    
}

class JSONPlaceholderModel : BaseModel<JSONPlaceholderService> {
    
    func login(account: String, password: String) -> Single<User> {
        
        return provider.rx.request(JSONPlaceholderService.Login(account: account, password: password)).mapArray(User.self).flatMap({ (results) -> PrimitiveSequence<SingleTrait, User> in
            if results.count <= 0 {
                throw JSONPlaceholderError.LoginFail
            } else {
                return Single.just(results.first!) 
            }
        })
        
    }

}

struct User : Mappable {
    
    var name: String? = nil
    var username: String? = nil
    
    init?(map: Map) {
        
    }
    
    mutating func mapping(map: Map) {
        name <- map["name"]
        username <- map["username"]
    }
    
}
