//
//  BaseModel.swift
//  RxExample
//
//  Created by Mize on 2019/1/9.
//  Copyright © 2019 Mize. All rights reserved.
//

import Foundation
import Alamofire
import Moya
import RxSwift

public final class BackgroundScheduler {
    public static let instance = SerialDispatchQueueScheduler(qos: DispatchQoS.background);
}

class BaseModel<T> where T : TargetType {
    
    var provider:MoyaProvider<T>;
    
    init(timeout:TimeInterval = 20) {
        let configuration = URLSessionConfiguration.default
        configuration.httpAdditionalHeaders = Alamofire.SessionManager.defaultHTTPHeaders
        configuration.timeoutIntervalForRequest = timeout // as seconds, you can set your request timeout
        configuration.timeoutIntervalForResource = timeout // as seconds, you can set your resource timeout
        configuration.requestCachePolicy = .useProtocolCachePolicy;
        
        self.provider = MoyaProvider<T>(manager: SessionManager(configuration: configuration));
    }
}

