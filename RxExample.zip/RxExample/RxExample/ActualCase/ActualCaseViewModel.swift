//
//  ActualCaseViewModel.swift
//  RxExample
//
//  Created by Mize on 2019/1/9.
//  Copyright © 2019 Mize. All rights reserved.
//

import Foundation
import RxSwift

class ActualCaseViewModel {
    
    enum ViewState {
        case Default
        case LoginSuccess(user: User)
        case LoginFail(error: Error)
    }
    
    var viewState: BehaviorSubject<ViewState> = BehaviorSubject(value: ViewState.Default);
    
    var bag = DisposeBag()
    
    var api = JSONPlaceholderModel()
    
    func login(account: String, password: String) {
        api.login(account: account, password: password).subscribe(onSuccess: { (user) in
            self.viewState.onNext(.LoginSuccess(user: user))
        }, onError: { (error) in
            self.viewState.onNext(.LoginFail(error: error))
        }).disposed(by: bag)
    }
    
}
