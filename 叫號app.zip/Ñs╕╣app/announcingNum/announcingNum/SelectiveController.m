//
//  SelectiveController.m
//  announcingNum
//
//  Created by Jamie on 2016/6/16.
//  Copyright © 2016年 JamieChen. All rights reserved.
//

#import "SelectiveController.h"
//#import "ToastView.h"
#import "NetworkController.h"
#import "ViewController.h"
#import "Constaint.h"

@implementation SelectiveController {
    NSString *text;
    ViewController *view;
}

-(void) viewDidLoad {
    [super viewDidLoad];
    
    self.mTextfield.keyboardType = UIKeyboardTypeNumberPad;
    self.mTextfield.delegate= self;
    
}

-(void) touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}

// 按鈕事件
- (IBAction)sendToCall:(id)sender {
    [self transfer:type];
}

// 傳送資料
- (void) transfer:(int)data {
    NSString *senderType;
    switch (data) {
        case 1:
            senderType = @"內用";
            break;
        case 2:
            senderType = @"外帶";
            break;
        case 3:
            senderType = @"1-2人";
            break;
        case 4:
            senderType = @"3-4人";
            break;
        default:
            senderType = nil;
            break;
    }
    
    if (_mTextfield.text.length == 0) {
//        [ToastView showToastInParentView:self.view withText:@"不可空白" withDuration:5.0];
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"不可空白"
                                                                       message:@"請輸入文字"
                                                                preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"關閉"
                                                     style:UIAlertActionStyleDefault
                                                   handler:nil];
        
        [alert addAction:ok];
        
        [self presentViewController:alert animated:YES completion:nil];
    } else {
        text = [[NSString alloc] initWithFormat:@"{\"object\":{\"id\":%d,\"number\":\"%d\",\"title\":\"%@\"},\"type\":62}", _receivedType, _mTextfield.text.intValue, senderType];
        
        _rType = _receivedType;
        number = (int)_mTextfield.text.integerValue;
        
//        [[self delegate] setTypeNumber:_rType];
//        [[self delegate] setNumber:_rNum];
        
        [[NetworkController sharedInstance] sendMessage:text];
        
        UIAlertController *alert = [[UIAlertController alloc]init];
        alert = [UIAlertController alertControllerWithTitle:@"開始叫號" message:[NSString stringWithFormat:@"%@叫號%d", senderType, number] preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"關閉" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
                [self BackBtn];
            }];
        
        [alert addAction:ok];
        [self presentViewController:alert animated:YES completion:nil];

    }
}

// 設定回去按鈕
-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    // back button
    UIButton *backBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 50, 24)];
    [backBtn setTitle:@"返回" forState:UIControlStateNormal];
    [backBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    UIBarButtonItem *barBackBtnItem = [[UIBarButtonItem alloc]initWithCustomView:backBtn];
    [backBtn addTarget:self action:@selector(BackBtn) forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.leftBarButtonItem = barBackBtnItem;
}

-(void)BackBtn {
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(BOOL) textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

-(BOOL) textFieldShouldEndEditing:(UITextField *)textField {
//    _rType = _receivedType;
    number = (int)_mTextfield.text.integerValue;
    return YES;
}

-(void)dealloc {
    [self.view removeFromSuperview];
}

@end
