//
//  NetworkController.h
//  announcingNum
//
//  Created by Jamie on 2016/6/16.
//  Copyright © 2016年 JamieChen. All rights reserved.
//

#import <UIKit/UIKit.h>

// Block typedefs
@class NetworkController;
typedef void (^ConnectionBlock)(NetworkController*);
typedef void (^MessageBlock)(NetworkController*,NSString*);


@interface NetworkController : NSObject<NSStreamDelegate> {
    // Connection info
    NSString* host;
    int port;
    
    // Input
    NSInputStream* inputStream;
    NSMutableData* inputBuffer;
    BOOL isInputStreamOpen;
    
    // Output
    NSOutputStream* outputStream;
    NSMutableData* outputBuffer;
    BOOL isOutputStreamOpen;
    
    // Event handlers
    MessageBlock messageReceivedBlock;
    ConnectionBlock connectionOpenedBlock;
    ConnectionBlock connectionFailedBlock;
    ConnectionBlock connectionClosedBlock;
    
    NSMutableArray *messages;
}

// Singleton instance
+ (NetworkController*)sharedInstance;

// Methods
//- (void)connection:(NSString *)ip_addr connecting_port:(int)c_port;
- (void)connect;
- (void)disconnect;
- (void)sendMessage:(NSString*)message;
- (BOOL)isConnected;

// Properties
@property (copy) MessageBlock messageReceivedBlock;
@property (copy) ConnectionBlock connectionOpenedBlock;
@property (copy) ConnectionBlock connectionFailedBlock;
@property (copy) ConnectionBlock connectionClosedBlock;
@end
