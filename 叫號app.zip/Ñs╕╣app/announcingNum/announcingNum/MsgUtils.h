//
//  MsgUtils.h
//  announcingNum
//
//  Created by Jamie on 2016/6/16.
//  Copyright © 2016年 JamieChen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextView (Utils)

- (void)scrollToBottom;
- (void)appendTextAfterLinebreak:(NSString *)text;

@end
