//
//  Constaint.m
//  announcingNum
//
//  Created by Jamie on 2016/11/16.
//  Copyright © 2016年 JamieChen. All rights reserved.
//

#import "Constaint.h"

@implementation Constaint

int type = 0;
int number = 0;

@end
