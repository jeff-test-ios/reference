//
//  ViewController.m
//  announcingNum
//
//  Created by Jamie on 2016/6/16.
//  Copyright © 2016年 JamieChen. All rights reserved.
//

#import "ViewController.h"
#import "CallNumberPopover.h"
//#import "ToastView.h"
#import "SelectiveController.h"
#import "NetworkController.h"
#import "Constaint.h"

@interface ViewController () {
    int declearType;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.data = [NSArray arrayWithObjects:@"下一號",@"重新呼叫",@"指定叫號", nil];
}

#pragma mark - where sorting out which label to display
// popover按鈕事件
- (void)showPopWithSource:(id)source type:(int)sender
{
    UILabel *currentLabel = _labelArray[sender - 1];
    NSString *senderType;
    declearType = sender;
    switch (sender) {
        case 1:
            senderType = @"內用";
            break;
        case 2:
            senderType = @"外帶";
            break;
        case 3:
            senderType = @"1-2人";
            break;
        case 4:
            senderType = @"3-4人";
            break;
        default:
            senderType = nil;
            break;
    }
    
    __block NSString *text = [[NSString alloc] initWithFormat:@"{\"object\":{\"id\":%d,\"number\":\"%d\",\"title\":\"%@\"},\"type\":62}",sender , currentLabel.text.intValue, senderType];
    
    CallNumberPopover *pop = [CallNumberPopover popoverViewControllerWithSourceView:source dataSource:self.data popoverDidSelectBlock:^(NSInteger index) {
        
        NSLog(@"----- %ld",index);
        switch (index) {
            case 0:
//                [ToastView showToastInParentView:self.view withText:@"這裏是下一號" withDuration:5.0];
                currentLabel.text = [NSString stringWithFormat:@"%d", currentLabel.text.intValue + 1];
                text = [[NSString alloc] initWithFormat:@"{\"object\":{\"id\":%d,\"number\":\"%d\",\"title\":\"%@\"},\"type\":62}", sender, currentLabel.text.intValue, senderType];
                [[NetworkController sharedInstance] sendMessage:text];
                break;
                
            case 1:
//                [ToastView showToastInParentView:self.view withText:@"這裏是重新呼叫" withDuration:5.0];
                text = [[NSString alloc] initWithFormat:@"{\"object\":{\"id\":%d,\"number\":\"%d\",\"title\":\"%@\"},\"type\":62}", sender, currentLabel.text.intValue, senderType];
                [[NetworkController sharedInstance] sendMessage:text];
                break;
                
            default:
                NSLog(@"%d", sender);
//                [self performSegueWithIdentifier:@"ddd" sender:nil];
                type = sender;
//                UINavigationController *navvc = [self.storyboard instantiateViewControllerWithIdentifier:@"select"];
//                
//                [self presentViewController:navvc animated:YES completion:nil];
                
                UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                UIViewController *vc = [sb instantiateViewControllerWithIdentifier:@"select"];
                UINavigationController *detailView = [[UINavigationController alloc]initWithRootViewController:vc];
                [self.navigationController presentViewController:detailView animated:YES completion:nil];
                
//                UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//                UIViewController *vc = [sb instantiateViewControllerWithIdentifier:@"select"];
//                
//                [self presentViewController:vc animated:YES completion:nil];
                break;
        }
    }];
    
    //    pop.popoverArrowDirection = UIPopoverArrowDirectionLeft;
    //    pop.cellHeight = 60;
    
    [self presentViewController:pop animated:YES completion:nil];
}

//#pragma mark - send data to 指定叫號
//- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
//    if ([segue.identifier isEqualToString:@"ddd"]) {
//        SelectiveController *controller = [segue destinationViewController];
//        controller.receivedType = declearType;
//    }
//}


//
//#pragma mark - Protocal Methods
//
//-(void) setTypeNumber:(int)returnedType {
//    _rType = returnedType;
//}
//-(void) setNumber:(int)returnedNum {
//    _rNum = returnedNum;
//}

-(void) viewWillAppear:(BOOL)animated {
    if (number != 0) {
        NSLog(@"returned Type: %d", number);
//        UILabel *currentLabel = _labelArray[_rType - 1];
        UILabel *currentLabel = _labelArray[type - 1];
        currentLabel.text = [NSString stringWithFormat:@"%d", number];
    }
}

//
//-(void) configureWidata:(NSArray *)paramData {
//    UILabel *returnedLabel = _labelArray[_returnedNum - 1];
//    returnedLabel.text = [NSString stringWithFormat:@"%d", _returnedNum];
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// 按鈕事件
#pragma mark - btn actions
- (IBAction)btnAction:(id)sender {
    [self showPopWithSource:sender type:1];
}
- (IBAction)takeOutBtn:(id)sender {
    [self showPopWithSource:sender type:2];
}

- (IBAction)fewPplBtn:(id)sender {
    [self showPopWithSource:sender type:3];
}

- (IBAction)morePplBtn:(id)sender {
    [self showPopWithSource:sender type:4];
}

// 連線
#pragma mark - connect
- (IBAction)connect:(id)sender {
    [[NetworkController sharedInstance] connect];
}

-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
    return YES;
}
@end
