//
//  ViewController.h
//  announcingNum
//
//  Created by Jamie on 2016/6/16.
//  Copyright © 2016年 JamieChen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SelectiveController.h"

@interface ViewController : UIViewController//<passNumbers>

@property (nonatomic, strong) NSArray *data;

@property (retain, nonatomic) IBOutletCollection(UILabel) NSArray *labelArray;

//@property int rType;
//@property int rNum;

- (IBAction)btnAction:(id)sender;
- (IBAction)takeOutBtn:(id)sender;
- (IBAction)fewPplBtn:(id)sender;
- (IBAction)morePplBtn:(id)sender;



@end

