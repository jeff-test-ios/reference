//
//  Connect.h
//  announcingNum
//
//  Created by Jamie on 2016/6/16.
//  Copyright © 2016年 JamieChen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Connect : UIViewController

@property (strong, nonatomic) IBOutlet UITextView *connectionStatus;
@end
