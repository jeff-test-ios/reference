//
//  Constaint.h
//  announcingNum
//
//  Created by Jamie on 2016/11/16.
//  Copyright © 2016年 JamieChen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Constaint : NSObject

extern int type;
extern int number;

@end
