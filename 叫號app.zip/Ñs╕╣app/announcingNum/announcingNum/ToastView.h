//
//  ToastView.h
//  announcingNum
//
//  Created by Jamie on 2016/6/16.
//  Copyright © 2016年 JamieChen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ToastView : UIView

@property (strong, nonatomic) NSString *text;

+ (void)showToastInParentView: (UIView *)parentView withText:(NSString *)text withDuration:(float)duration;

@end
