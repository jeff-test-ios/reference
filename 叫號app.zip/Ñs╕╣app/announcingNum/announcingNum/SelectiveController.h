//
//  SelectiveController.h
//  announcingNum
//
//  Created by Jamie on 2016/6/16.
//  Copyright © 2016年 JamieChen. All rights reserved.
//

#import <UIKit/UIKit.h>

//@protocol passNumbers <NSObject>
//
//-(void) setTypeNumber:(int)returnedType;
//-(void) setNumber:(int)returnedNum;
//
//@end

@interface SelectiveController : UIViewController<UITextFieldDelegate>
@property (strong, nonatomic) IBOutlet UITextField *mTextfield;
@property int receivedType;
//@property (retain) id <passNumbers> delegate;
@property int rType;
@property int rNum;

- (IBAction)sendToCall:(id)sender;

@end
