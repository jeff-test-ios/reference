//
//  Connect.m
//  announcingNum
//
//  Created by Jamie on 2016/6/16.
//  Copyright © 2016年 JamieChen. All rights reserved.
//  沒有在用

#import "Connect.h"
#import "NetworkController.h"
#import "MsgUtils.h"

#pragma mark - Private properties and methods

@interface Connect ()
- (void)displayMessage:(NSString*)message;
@end

@implementation Connect

-(void) viewDidLoad {
    [super viewDidLoad];
    _connectionStatus.text = @"";
    
    // Enable input and show keyboard as soon as connection is established.
    [NetworkController sharedInstance].connectionOpenedBlock = ^(NetworkController* connection){
        [_connectionStatus setUserInteractionEnabled:YES];
        [_connectionStatus becomeFirstResponder];
        [self displayMessage:@">>> 連 線 開 啟 <<<"];
    };
    
    // Disable input and hide keyboard when connection is closed.
    [NetworkController sharedInstance].connectionClosedBlock = ^(NetworkController* connection){
        [_connectionStatus resignFirstResponder];
        [_connectionStatus setUserInteractionEnabled:NO];
        [self displayMessage:@">>> 連 線 關 閉 <<<"];
    };
    
    // Display error message and do nothing if connection fails.
    [NetworkController sharedInstance].connectionFailedBlock = ^(NetworkController* connection){
        [self displayMessage:@">>> 連 線 失 敗 <<<"];
    };
}

- (void)displayMessage:(NSString*)message {
    // These two came from UITextView+Utils.h
    [_connectionStatus appendTextAfterLinebreak:message];
    [_connectionStatus scrollToBottom];
}

- (IBAction)connect:(id)sender {
    [[NetworkController sharedInstance] connect];
    if ([[NetworkController sharedInstance] isConnected]) {
        [self performSegueWithIdentifier:@"callNum" sender:self];
    }
}

-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
    return YES;
}

@end
