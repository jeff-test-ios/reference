import XCTest

import SHCoreTests

var tests = [XCTestCaseEntry]()
tests += SHCoreTests.allTests()
XCTMain(tests)
