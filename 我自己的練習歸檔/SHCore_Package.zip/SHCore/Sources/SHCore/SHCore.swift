struct SHCore {
    var text = "Hello, World!"
}
