// TARGETS —> Build Settings
// Build Active Architecture Only 设置为 NO
// linking 设置 Dead Code Stripping 为 NO: 编译选项优化,包瘦身,(可不改)
// Mach-O Type 选中 StaticLibrary: Xcode默认是动态库

// 设置framework最低支持的版本(如果有需要的話啦)

// 编译以下四种情况，注意：framework由红变黑表示编译通过。
// ① debug 模式 模拟器运行
// ② debug 模式 真机运行
// ③ release 模式 模拟器运行
// ④ release 模式 真机运行

import Foundation

public protocol SHConsole {
    /// 顯示 console 訊息，並帶有 👻 字符前綴作為提示。此外，也確保只有在 debug 模式下才會作用。
    func showMessage(_ messages: Any..., method: String)
}

extension SHConsole {
    // 實作協定方法
    public func showMessage(_ messages: Any..., method: String = #function) {
        #if DEBUG
        print("👻👻👻", terminator: " ")
        if messages.isEmpty {
            print("no message")
        } else if messages.count == 1 {
            print(messages[0])
        } else {
            self.printMultiMessage(messages)
        }
        #endif
    }
    
    /// 多參數時的行為，獨立抽出來成為一個方法。
    private func printMultiMessage(_ messages: [Any]) {
        var dataList = messages
        let last = dataList.removeLast()
        for data in dataList {
            print("\(data), ", terminator: "")
        }
        print(last)
    }
}
