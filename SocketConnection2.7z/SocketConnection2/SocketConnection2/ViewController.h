//
//  ViewController.h
//  SocketConnection2
//
//  Created by Jamie on 2016/5/27.
//  Copyright © 2016年 JamieChen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <arpa/inet.h>
#import <ifaddrs.h>

@interface ViewController : UIViewController<UITextFieldDelegate> {
    IBOutlet UITextField *messageSendTextfield;
}
    // Methods
- (IBAction)connect:(id)sender;

@property (weak, nonatomic) IBOutlet UILabel *local_IP_Label;
@property (weak, nonatomic) IBOutlet UITextView *textViewOutput;

@property (weak, nonatomic) IBOutlet UITextField *connection_IP_TextField;
@property (weak, nonatomic) IBOutlet UITextField *connection_port_TextField;

- (IBAction)disconnect:(id)sender;
- (IBAction)msgSend:(id)sender;
- (IBAction)callDemo1:(id)sender;
- (IBAction)callDemo2:(id)sender;

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event;
@end

