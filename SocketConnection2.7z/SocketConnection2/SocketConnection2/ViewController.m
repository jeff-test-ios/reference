//
//  ViewController.m
//  SocketConnection2
//
//  Created by Jamie on 2016/5/27.
//  Copyright © 2016年 JamieChen. All rights reserved.
//

#import "ViewController.h"
#import "NetworkController.h"
#import "MsgUtils.h"


#pragma mark - Private properties and methods

@interface ViewController ()
- (void)displayMessage:(NSString*)message;
@end


@implementation ViewController

#pragma mark - Private methods

- (void)displayMessage:(NSString*)message {
    // These two came from UITextView+Utils.h
    [_textViewOutput appendTextAfterLinebreak:message];
    [_textViewOutput scrollToBottom];
}


#pragma mark - Public methods

- (IBAction)connect:(id)sender {
    [[NetworkController sharedInstance] connection:_connection_IP_TextField.text connecting_port:[_connection_port_TextField.text intValue]];
}

- (IBAction)disconnect:(id)sender {
    [[NetworkController sharedInstance] disconnect];
}

- (IBAction)msgSend:(id)sender {
    [[NetworkController sharedInstance] sendMessage:messageSendTextfield.text];
    [self displayMessage:messageSendTextfield.text];
    [messageSendTextfield setText:@""];
}

// 叫號模擬
- (IBAction)callDemo1:(id)sender {
    
    NSString *demo = @"{\"object\":{\"id\":1,\"number\":\"1002\",\"title\":\"內用\"},\"type\":62}";
    [[NetworkController sharedInstance] sendMessage:demo];
}

// 設定模擬
- (IBAction)callDemo2:(id)sender {
    NSString *demo = @"{\"object\":{\"callerAmount\":4,\"picPlayTime\":10,\"titleList\":[\"內用\",\"外帶\",\"1-2人\",\"3-4人\"]}, \"type\":61}";
    [[NetworkController sharedInstance] sendMessage:demo];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    _local_IP_Label.text = [self getIpAddress];
    _textViewOutput.text = @"";
    
    self.connection_IP_TextField.text = @"192.168.43.1";
    self.connection_port_TextField.text = @"8888";
    
    // Enable input and show keyboard as soon as connection is established.
    [NetworkController sharedInstance].connectionOpenedBlock = ^(NetworkController* connection){
        [messageSendTextfield setUserInteractionEnabled:YES];
        [messageSendTextfield becomeFirstResponder];
        messageSendTextfield.text = @"請輸入訊息";
        [self displayMessage:@">>> 開 啟 連 線 <<<"];
    };
    
    // Disable input and hide keyboard when connection is closed.
    [NetworkController sharedInstance].connectionClosedBlock = ^(NetworkController* connection){
        [messageSendTextfield resignFirstResponder];
        [messageSendTextfield setUserInteractionEnabled:NO];
        [self displayMessage:@">>> 關 閉 連 線 <<<"];
    };
    
    // Display error message and do nothing if connection fails.
    [NetworkController sharedInstance].connectionFailedBlock = ^(NetworkController* connection){
        [self displayMessage:@">>> 連 線 失 敗 <<<"];
    };
    
    // Append incoming message to the output text view.
    [NetworkController sharedInstance].messageReceivedBlock = ^(NetworkController* connection, NSString* message){
        [self displayMessage:message];
    };
    
    messageSendTextfield.delegate = self;
}

// http://stackoverflow.com/questions/6807788/how-to-get-ip-address-of-iphone-programatically
// this is to get the localhost ip address
-(NSString *)getIpAddress {
    NSString *address = @"error";
    struct ifaddrs *interfaces = NULL;
    struct ifaddrs *temp_addr = NULL;
    int success = 0;
    
    // retrieve the current interface - returns 0 on success
    success = getifaddrs(&interfaces);
    if (success == 0) {
        temp_addr = interfaces;
        while (temp_addr != NULL) {
            if (temp_addr -> ifa_addr -> sa_family == AF_INET) {
                // check if interface is en0 which is the wifi connection on the iPhone
                if ([[NSString stringWithUTF8String:temp_addr->ifa_name] isEqualToString:@"en0"]) {
                    //get nsstring from c string
                    address = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)];
                }
            }
            temp_addr = temp_addr->ifa_next;
        }
    }
    //free memory
    freeifaddrs(interfaces);
    return address;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    [NetworkController sharedInstance].connectionOpenedBlock = nil;
    [NetworkController sharedInstance].connectionFailedBlock = nil;
    [NetworkController sharedInstance].connectionClosedBlock = nil;
    [NetworkController sharedInstance].messageReceivedBlock = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations.
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}


#pragma mark - UITextFieldDelegate methods
// Called when user taps 'enter' on the on-screen keyboard
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [[NetworkController sharedInstance] sendMessage:textField.text];
    [self displayMessage:textField.text];
    [textField setText:@""];
    // 將keyboard關閉
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - keyboard hide
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}

@end
