//
//  NetworkController.h
//  SocketConnection2
//
//  Created by Jamie on 2016/5/30.
//  Copyright © 2016年 JamieChen. All rights reserved.
//

//#import <Foundation/Foundation.h>
//
//@interface NetworkController : NSObject
//
//@end


#import <Foundation/Foundation.h>


// Block typedefs
@class NetworkController;
typedef void (^ConnectionBlock)(NetworkController*);
typedef void (^MessageBlock)(NetworkController*,NSString*);


@interface NetworkController : NSObject<NSStreamDelegate> {
    // Connection info
    NSString* host;
    int port;
    
    // Input
    NSInputStream* inputStream;
    NSMutableData* inputBuffer;
    BOOL isInputStreamOpen;
    
    // Output
    NSOutputStream* outputStream;
    NSMutableData* outputBuffer;
    BOOL isOutputStreamOpen;
    
    // Event handlers
    MessageBlock messageReceivedBlock;
    ConnectionBlock connectionOpenedBlock;
    ConnectionBlock connectionFailedBlock;
    ConnectionBlock connectionClosedBlock;
    
    NSMutableArray *messages;
}

// Singleton instance
+ (NetworkController*)sharedInstance;

// Methods
- (void)connection:(NSString *)ip_addr connecting_port:(int)c_port;
- (void)disconnect;
- (void)sendMessage:(NSString*)message;

// Properties
@property (copy) MessageBlock messageReceivedBlock;
@property (copy) ConnectionBlock connectionOpenedBlock;
@property (copy) ConnectionBlock connectionFailedBlock;
@property (copy) ConnectionBlock connectionClosedBlock;


@end
