//
//  MsgUtils.h
//  SocketConnection2
//
//  Created by Jamie on 2016/5/27.
//  Copyright © 2016年 JamieChen. All rights reserved.
//
#import <UIKit/UITextView.h>

@interface UITextView (Utils)

- (void)scrollToBottom;
- (void)appendTextAfterLinebreak:(NSString *)text;

@end
