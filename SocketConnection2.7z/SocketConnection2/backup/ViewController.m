//
//  ViewController.m
//  SocketConnection2
//
//  Created by Jamie on 2016/5/27.
//  Copyright © 2016年 JamieChen. All rights reserved.
//

#import "ViewController.h"
#import "NetworkController.h"
#import "MsgUtils.h"


#pragma mark - Private properties and methods

@interface ViewController ()
- (void)displayMessage:(NSString*)message;
@end


@implementation ViewController

#pragma mark - Private methods

- (void)displayMessage:(NSString*)message {
    // These two came from UITextView+Utils.h
    [textViewOutput appendTextAfterLinebreak:message];
    [textViewOutput scrollToBottom];
}


#pragma mark - Public methods

- (IBAction)connect:(id)sender {
    [[NetworkController sharedInstance] connect];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Enable input and show keyboard as soon as connection is established.
    [NetworkController sharedInstance].connectionOpenedBlock = ^(NetworkController* connection){
        [textInput setUserInteractionEnabled:YES];
        [textInput becomeFirstResponder];
        [self displayMessage:@">>> Connection opened <<<"];
    };
    
    // Disable input and hide keyboard when connection is closed.
    [NetworkController sharedInstance].connectionClosedBlock = ^(NetworkController* connection){
        [textInput resignFirstResponder];
        [textInput setUserInteractionEnabled:NO];
        [self displayMessage:@">>> Connection closed <<<"];
    };
    
    // Display error message and do nothing if connection fails.
    [NetworkController sharedInstance].connectionFailedBlock = ^(NetworkController* connection){
        [self displayMessage:@">>> Connection FAILED <<<"];
    };
    
    // Append incoming message to the output text view.
    [NetworkController sharedInstance].messageReceivedBlock = ^(NetworkController* connection, NSString* message){
        [self displayMessage:message];
    };
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    [NetworkController sharedInstance].connectionOpenedBlock = nil;
    [NetworkController sharedInstance].connectionFailedBlock = nil;
    [NetworkController sharedInstance].connectionClosedBlock = nil;
    [NetworkController sharedInstance].messageReceivedBlock = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations.
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}


#pragma mark - UITextFieldDelegate methods
// Called when user taps 'enter' on the on-screen keyboard
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [[NetworkController sharedInstance] sendMessage:textField.text];
    [self displayMessage:textField.text];
    [textField setText:@""];
    return YES;
}
@end
