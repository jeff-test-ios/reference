//
//  ViewController.h
//  SocketConnection2
//
//  Created by Jamie on 2016/5/27.
//  Copyright © 2016年 JamieChen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITextFieldDelegate> {
    IBOutlet UITextView *textViewOutput;
    IBOutlet UITextField *textInput;
}
// Methods
- (IBAction)connect:(id)sender;

//@property (weak, nonatomic) IBOutlet UILabel *local_IP_Label;
//@property (weak, nonatomic) IBOutlet UITextField *connection_IP_TextField;
//@property (weak, nonatomic) IBOutlet UITextField *connection_port_TextField;
//@property (weak, nonatomic) IBOutlet UITextField *messageSendTextField;
//@property (weak, nonatomic) IBOutlet UITextView *messageDisplayTextview;
//- (IBAction)connect:(id)sender;
//- (IBAction)disconnect:(id)sender;
//- (IBAction)msgSend:(id)sender;

@end

